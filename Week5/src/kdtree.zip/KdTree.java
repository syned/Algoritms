/**
 * Created by IntelliJ IDEA.
 * User: syned
 * Date: 16.09.12
 * Time: 18:13
 * To change this template use File | Settings | File Templates.
 */
public class KdTree {

    public KdTree() {

    }

    public boolean isEmpty() {
        return false;
    }
    public int size() {
        return 0;
    }
    public void insert(Point2D p) {
    }
    public boolean contains(Point2D p) {
        return false;
    }
    public void draw() {
    }
    public Iterable<Point2D> range(RectHV rect) {
        Queue<Point2D> queue = new Queue<Point2D>();
        return queue;
    }
    public Point2D nearest(Point2D p) {
        Point2D nearest = null;
        return nearest;
    }
}
